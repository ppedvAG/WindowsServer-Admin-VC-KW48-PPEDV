﻿#Prüfen von TCP Ports
Test-NetConnection -ComputerName www.google.de -Port 443

#Ping Alternative
#Source is optional, man kann allerdings sowohl beim Namen als auch bei source mit komma getrennt mehrere Server angeben
Test-Connection -ComputerName Server2 -Source Server1


#Package Management
#Erst die Execution Policy ändern

Set-executionPolicy RemoteSigned

#installiert chocolatey wenn er noch nicht installiert ist, es kann auch die Abfrage von Nuget kommen welcher auch installiert werden muss.

Get-PackageProvider -Name "Chocolatey" -ForceBootstrap

#Pakete finden

Find-Package Notepad

#Pakete installieren

Install-Package notepadplusplus
