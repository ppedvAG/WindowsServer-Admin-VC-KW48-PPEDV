﻿##Container

##alle Updates

##Feature-> Container installieren

Install-Module -Name DockerMsftProvider -Repository PSGallery -Force

Install-Package -Name docker -ProviderName DockerMsftProvider

Restart-Computer -Force

###bei Bedarf nochmals Patchen

sconfig

###Beispiel
docker run microsoft/dotnet-samples:dotnetapp-nanoserver-1809